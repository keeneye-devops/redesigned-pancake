<p id="multiple-domain">
    <?php _e('You can use multiple domains in your WordPress defining them below. '
        . 'It\'s possible to limit the access for each domain to a base URL.', 'multiple-domain'); ?>
</p>
